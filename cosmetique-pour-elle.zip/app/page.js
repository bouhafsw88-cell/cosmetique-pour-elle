export default function Home() {
  return (
    <main style={{padding:'20px'}}>
      <h1>Cosmétique Pour Elle</h1>
      <p>Produits NIVEA - Paiement à la livraison</p>
    </main>
  )
}