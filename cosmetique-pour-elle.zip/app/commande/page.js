export default function Commande() {
  return (
    <form style={{padding:'20px'}}>
      <h2>Paiement à la livraison</h2>
      <input placeholder="Nom" /><br/>
      <input placeholder="Téléphone" /><br/>
      <input placeholder="Adresse" /><br/>
      <button>Commander</button>
    </form>
  )
}